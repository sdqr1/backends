from mock_data import catalog



def find_prod():
    text = " "






find_prod()